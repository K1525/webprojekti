<?php
session_start();
//Haetaan poistettavan tuotteen id
$id = $_GET['id'];

//Poistetaan rivi matriisista
unset($_SESSION['cart'][$id]);
//Uudelleen määrätään indeksit
$_SESSION['cart'] = array_values($_SESSION['cart']);

//Jos Kori on tyhjä id = 0
if(sizeof($_SESSION['cart']) == 0){
    $_SESSION['id'] = 0;
}

//Id ei ole koskaan isompi kuin korin pituus
$_SESSION['id'] = sizeof($_SESSION['cart']);

//Vaihdetaan delete linkit
$length = sizeof($_SESSION['cart']);
for($i = 0; $i < $length; $i++){
    $_SESSION['cart'][$i][3] = "<a href='v0.2/subtractItem.php?id={$id}'><span class='glyphicon glyphicon-minus' aria-hidden='true'></span></a>  <a href='v0.2/addItem.php?id={$id}'><span class='glyphicon glyphicon-plus' aria-hidden='true'></span></a>  <a href='v0.2/delete.php?id={$id}'><span class='glyphicon glyphicon-trash' aria-hidden='true'></span></a>"; 
}
header("Location: ../index.php");
?>