

<?php 
session_start();
        require_once("db-init.php");
        include("../v0.2/cart-test.php");
        $sql = "select ProductId, Name, Price, Description_more, gender, File_name
                from product join product_image
                on product_ProductId = ProductId
                WHERE ProductId LIKE {$_GET['id']}";
        $stmt = $db->query("$sql"); 


    $_SESSION['productName'] = "";
    $_SESSION['price'] = "";
    $_SESSION['amount'] = 0;
    $_SESSION['productId'] = 0;
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $_SESSION['productName'] = $row['Name'];
        $_SESSION['price'] = $row['Price'];        
        $_SESSION['productId'] = $row['ProductId'];
        echo    "<div class='isoproduct'>
                    <img src='../images/{$row['File_name']}.png' class='tuotekuvapop'/>
                        <div class='nimipop'>{$row['Name']} </div>
                        <div class='hintapop'>{$row['Price']} </div>
                        <div class='kuvauspop'>{$row['Description_more']}</div>
                        
                        <form method='post' action='../v0.2/addToCart.php'>
                            <select name='amount'>
                              <option value='1'>1</option>
                              <option value='2'>2</option>
                              <option value='3'>3</option>
                              <option value='4'>4</option>
                              <option value='5'>5</option>
                            </select>
                            <input id='addToCart' type='submit' name='submitCart' class='btn btn-default' value='Lisää ostoskoriin'>
                        </form>                
                </div>";  
    } 
    
echo '<div id="commentlist">';

include('../post-comment.php');
echo '</div>';
?>


<body>
   
   <div id="commentform"> 
       
       <h3>Jätä kommentti</h3>      
       
       <form action="../post-comment.php" method="post" id="commentform">        
                  
           
            <div id=arvioarea>
                <label for="comment" class="required">Kommentti:</label>
                <textarea name="comment" id="comment" rows="10" tabindex="4"  required="required" class="form-control"></textarea>
           </div>       
            <input type="hidden" name="comment_post_ID" value="1" id="comment_post_ID" />
            <input name="submit" type="button" value="Lähetä" id="commentbutton" class="btn btn-default"/>        
       
       </form>    
    
    </div>
   
</body>
