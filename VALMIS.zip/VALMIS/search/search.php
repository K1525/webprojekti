<head>  
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <script type="text/javascript" src="../jquery-3.1.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    
    <!--CSS-->
    <link type="text/css" rel="stylesheet" href="style.css">
    <link type="text/css" rel="stylesheet" href="../navbar/navbar.css">
    <script src="popup.js" type="text/javascript"></script>
</head>
<body>
    <?php
    include("../navbar/test2.php");
    ?>
        <!-- POPUP CONTENT -->
        <div id="myModal" class="modal">
            <!-- Popup content -->
            <div class="modal-content">
                <span class="close">&times;</span>
            </div>
        </div>
    
        <div class="container">
        
        <div class="row">   
        <?php
            require_once("db-init.php");
        
            if(isset($_SESSION['searchWord'])){
                //$stmt = $db->prepare("SELECT * FROM product WHERE Name LIKE ? OR Description LIKE ?");                
                $stmt = $db->prepare("SELECT * FROM (SELECT * FROM product WHERE Name LIKE ? OR Description LIKE ?) AS pr INNER JOIN product_image AS im ON pr.ProductId = im.product_ProductId");
                /*
                
                SELECT *
                FROM product WHERE Name LIKE ? OR Description LIKE ? JOIN product_image
                ON product_ProductId = ProductId
                
                */
                $keyword = $_SESSION['searchWord'];
                $keyword = "%".$_SESSION['searchWord']."%";
                $stmt->execute(array($keyword, $keyword)); 
                $rowCount = 0;
                //Tulostetaan käyttöliittymään
                while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {  
                    echo "<div class='col-md-5 product' id='{$row['ProductId']}'>";
                    echo "<div class='col-md-8'>"; 
                    echo "<img src='../images/{$row['File_name']}.png' alt='image' class='img'>";
                    echo "</div>";                    
                    echo "<div class='col-md-4 info'>";
                    echo "<h1>{$row['Name']}</h1><br>\n";
                    echo "<h4>{$row['Description']}</h4><br>\n";
                    echo "<h3>{$row['Price']}</h3><br>\n";
                    //echo "<a href='{$row['ProductId']}'>Siirry tuotesivulle</a>";                      
                    echo "</div>"; //info
                    echo "</div>"; //row
                    $rowCount = $rowCount + 1;                    
                }
                
                //Jos ei löydy yhtään tuotetta hakuehdoilla
                if($rowCount == 0){
                    echo "Hakusanalla ei löytynyt yhtään tuotetta.";
                }
                //unset $_SESSION['searchWord'];                
            }            
            
        ?>  
        </div>
    </div>


</body>