<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Black Banana Hallinnointisivu</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Varela+Round" rel="stylesheet">
</head>
<?php
session_start();
    include("php/auth.php");
?>
<body>
    <div id="page" style="background-image:url('img/sayagata.png');min-height:100vh;">    
        <div class="row">
            <div id="left-nav" class="col-md-2 col-md-offset-1"></div>
            <div id="main-management" class="col-md-7">
                <div id="container" />
            </div>
        </div>
        <div id="footer"/>
    </div>
<script src="bundle.js" charset="utf-8"></script>
<!--Production: <script src="http://localhost:8080/public/bundle.js" charset="utf-8"></script>-->
</body>
</html>