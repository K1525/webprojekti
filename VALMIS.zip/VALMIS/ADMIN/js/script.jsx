import AddProductPage from './AddProductPage.jsx';
import ListProductsPage from './ListProductsPage.jsx';
import AddUserPage from './AddUserPage.jsx';
import ListOrdersPage from './ListOrdersPage.jsx';
import DialogBox from './Dialog.jsx';
import React from 'react';
import ReactDOM from 'react-dom';
import $ from 'jquery';

// Globaalit muuttujat
var mostChars = /^[a-zA-Z0-9-.,äöåü ]*$/;
var basicChars = /^[a-zA-Zäöåü ]*$/;
var product = [];
var image;
var user = [];
var address = [];
var fs = " > :first-child > :nth-child(2)";
var fsf = " > :first-child > :nth-child(2) > :first-child";

// Alareunan viesti-palkki
function showMessage(msg){
	$("#message-text").stop().text(msg).fadeIn();
	$("#snackbar").stop().animate({height: "120px"});
	setTimeout(function(){
		$("#snackbar").stop().animate({height: "0px"});
		$("#message-text").stop().fadeOut();
	},3000);
}

// Tarkastetaan kenttien dataa. 
// Tarkoitus oli tietenkin tehdä koodi jsx-tiedostoon, mutta siinä tuli ongelmia, joten tämä "hack" saa kelvata. Ensi kerralla fiksummin
function productRegExCheck(){
	var productName = $("#p1_1"+fs).val();
	var price = $("#p1_2"+fs).val();
	var description = $("#p2_1"+fs).val();
	var descriptionMore = $("#p3_1"+fsf).val();
	var gender = $("#Sukupuoli").val();
	if (gender == "1") gender = null;
	else if (gender == "2") gender = "m";
	else if (gender == "3") gender = "n";
	if ($("#category").val()==null) var category = 7;
	else var category = $("#category").val();
	var img = $("#fd-img").data();

	// Regex ja muut testit
	if (productName == "" || productName.length > 255 || mostChars.test(productName) == false){
		showMessage("Merkitse tuotenimi (255 merkkiä)");
		return false;
	}
	if (price == "" || !$.isNumeric(price)){
		showMessage("Merkitse hinta");
		return false;
	}
	if (description.length > 1024 || mostChars.test(description) == false){
		showMessage("Merkitse tuotetiedot");
		return false;
	}

	product = [];
	product.push(productName,price,5,description,descriptionMore,gender,category);
	image = img;
    return true;
}

// Sama juttu, mutta käyttäjätietojen kentille
function userRegExCheck(){
	var username = $("#u1_1"+fs).val();
	var password = $("#u1_2"+fs).val();
	var firstname = $("#u1_3"+fs).val();
    var lastname = $("#u1_4"+fs).val();
    var email = $("#u1_5"+fs).val();
	var phone = $("#u1_6"+fs).val();
	if ($("#Käyttäjätaso").val()==null) var userLevel = 1;
    else var userLevel = $("#Käyttäjätaso").val();
	var street = $("#u2_1"+fs).val();
	var zip = $("#u2_2"+fs).val();
	var city = $("#u2_3"+fs).val();
    var country = $("#u2_4"+fs).val();

	// Regex ja muut testit
	if (username == "" || username.length > 16 || username.length < 4 || mostChars.test(username) == false){
		showMessage('Merkitse käyttäjänimi (kirjaimia/numeroita) (5-16 merkkiä)');
		return false;
	}
	if (password == "" || password.length > 64 || password.length < 5 || basicChars.test(password) == false){
		showMessage("Merkitse salasana (kirjaimia/numeroita) (5-64 merkkiä)");
		return false;
	}
	if (firstname == "" || firstname.length > 220 || basicChars.test(firstname) == false){
		showMessage("Metkitse etunimi");
		return false;
	}
	if (lastname == "" || firstname.length > 220 || basicChars.test(firstname) == false){
		showMessage("Merkitse sukunimi");
		return false;
	}
	if (email == "" || email.length > 220){
		showMessage("Merkitse käyttäjä (pituus 5-16 merkkiä)");
		return false;
	}
	if (mostChars.test(street) || mostChars.test(street) || mostChars.test(country) || mostChars.test(city)){
		showMessage("Tarkista osoitetiedot.");
		return false;
	}

	user = [];
	user.push(username,password,firstname,lastname,email,phone,userLevel);
	address = [];
	address.push(street,zip,city,country);
    return true;
}

// Self-explanatory
function submitForm(form){
    form.submit();
}

// Poistetaan tiedostot
function removeProducts(){
	var ids = $("#ids").data();
	if (!ids) {
		showMessage("Valitse ensin tuotteita");
		return;
	}
	$.ajax({
		method: "POST",
		url: "./php/remove_products.php",
		data: {'ids':ids}
	}).done(function(data) {
		console.log(data);
		if(data == "Tuotteet poistettu")
			showMessage(data);
		else showMessage("Poistaminen epäonnistui");
	});
  }

// Lisätään tuote ajaxilla PHP:n kautta tietokantaan
function addProductToDb() {
	$.ajax({
		method: "POST",
 		url: "./php/add_product.php",
		data: {'product':product, 'img':image}
	}).done(function(data) {
		if(data == "Tuote lisätty"){
			$("#container").html("");
			ReactDOM.render(<AddProductPage/>,$("#container")[0]);
			showMessage("Tuote lisätty");
		}
		else showMessage("Lisääminen epäonnistui");
	});
}

// Sama juttu käyttäjälle
function addUserToDb() {
	$.ajax({
		method: "POST",
 		url: "./php/add_user.php",
		data: {
			'user':user,
			'address':address
		}
	}).done(function(data) {
		console.log(data);
  		if(data == "Käyttäjä lisätty"){
		  	$("#container").html("");
			ReactDOM.render(<AddUserPage/>,$("#container")[0]);
			showMessage(data);
		}
		else showMessage("Lisääminen epäonnistui");
	});
}

$(document).ready(function(){

	// Ikävä tehdä tällaista koodia
	$(document).on("click", "#remove-products-btn > :first > :first", function(){
		removeProducts();
	});

	$(document).on("click", "#add-product-btn > :first > :first", function(){
		if (productRegExCheck()){
            addProductToDb();
		}
    });
	$(document).on("click", "#add-user-btn > :first > :first", function(){
		if (userRegExCheck()){
        	addUserToDb();
		}
    });
});