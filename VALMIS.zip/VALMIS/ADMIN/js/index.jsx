// CSS
import '../css/main.scss';
import Bootstrap from 'bootstrap/dist/css/bootstrap.css';

// React, JS, JSX
import React from 'react';
import ReactDOM from 'react-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import $ from 'jquery';
import { SideNav, Nav } from 'react-sidenav';
import MainPage from './MainPage.jsx';
import AddProductPage from './AddProductPage.jsx';
import ListProductsPage from './ListProductsPage.jsx';
import AddUserPage from './AddUserPage.jsx';
import ListOrdersPage from './ListOrdersPage.jsx';
import ListUsersPage from './ListUsersPage.jsx';
import Snackbar from './Snackbar.jsx';
import './script.jsx';
import injectTapEventPlugin from 'react-tap-event-plugin';

// Ilman tätä kaikki menee rikki
injectTapEventPlugin();

// Navigaatio, joka olisi toisessa tiedostossa, jos olisi fiksu
var navi = [
    { id: 'menu-products', text: 'Tuotehallinta',
        navlist: [
          { id: 'menu-add-products' ,text: 'Lisää Tuote' },
          { id: 'menu-list-products' ,text: 'Näytä Tuotteet' }
        ]
    },
    { id: 'menu-users', text: 'Käyttäjähallinta',
        navlist: [
          { id: 'menu-add-users' ,text: 'Lisää Käyttäjä' },
          { id: 'menu-list-users' ,text: 'Käyttäjät' }
        ]
    },
    { id: 'menu-orders', text: 'Tilaukset'},
    { id: 'menu-store', text: 'Takaisin Verkkokauppaan'},
    { id: 'menu-logout', text: 'Kirjaudu Ulos'},
];

// Navigointivalikko, joka käyttää ylläolevaa navia
const SideNavComponent = React.createClass({
    getInitialState() {
        return { selected: '' };
    },
    // Asetetaan valittu valikko stateen ja tehdään jatkotoimenpiteet
    onSelection(selection) {
        this.setState({selected: selection.id});
        switch (selection.id){
            case 'menu-add-products': animateRender(<AddProductPage />); break;
            case 'menu-list-products': getProducts(); break;
            case 'menu-add-users': animateRender(<AddUserPage />); break;
            case 'menu-list-users': getUsers(); break;
            case 'menu-orders': getOrders(); break;
            case 'menu-store': window.location.href = "../"; break;
            case 'menu-logout': confirmLogout(); window.location.href = "../"; break;
        }
    },
    render() {
        return <div ><SideNav selected={this.state.selected} navs={navi} 
        onSelection={this.onSelection} /></div>
    }
});

// Useaan otteeseen käytetyt elementit
var main = $("#main-management");
var container = $("#container");

// Animaatio-funktio renderöinnin yhteydessä
function animateRender(reactElement){
    container.fadeOut(350,function(){
        container.html("");
        container.fadeIn(350);
        ReactDOM.render(reactElement,container[0]);
    });
}

// Tarkoitus oli kysyä käyttäjältä uloskirjautumisesta, mutta se jäi vielä tekemättä. Kirjaudutaan kuitenkin ulos.
function confirmLogout(){
    $.ajax({
 		url: "./php/logout.php"
    });
}

// Ajax kutsuja PHP:lle ja sieltä tietokannan datan hakeminen
function getProducts(param){
	$.ajax({
 		url: "./php/get_products.php",
        method: "POST",
        data: { "param":param }
    }).done(function(data) {
        data = $.parseJSON(data);
        animateRender(<ListProductsPage products={data} />);
	});
}

function getOrders(param){
	$.ajax({
 		url: "./php/get_orders.php",
        method: "POST",
        data: { "param": param }
    }).done(function(data) {
        data = $.parseJSON(data);
        animateRender(<ListOrdersPage orders={data} />);
	});
}

function getUsers(param){
	$.ajax({
 		url: "./php/get_users.php",
        method: "POST",
        data: { "param": param }
    }).done(function(data) {
        data = $.parseJSON(data);
        animateRender(<ListUsersPage users={data} />);
	});
}

$(document).ready(function(){
    container.fadeIn(600);
    ReactDOM.render(<SideNavComponent />, $("#left-nav")[0]);
    ReactDOM.render(<MainPage />, container[0]);    
    ReactDOM.render(<Snackbar />, $("#footer")[0]);

    // Hakukentän triggerit
    $(document).on("keyup","#search-orders",function(e){
        if (e.which == 13) {
            getOrders($("#search-orders").val());
        }
    });
    $(document).on("keyup","#search-product",function(e){
        if (e.which == 13) {
            getProducts($("#search-product").val());
        }
    });
    $(document).on("keyup","#search-users",function(e){
        if (e.which == 13) {
            getUsers($("#search-users").val());
        }
    });
});