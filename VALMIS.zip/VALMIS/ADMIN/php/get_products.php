<?php
require_once ("db-init.php");

// Haetaan tuotetiedot
$sql;
$stmt;
$sql = "SELECT ProductId,Name,Price,Gender,Description,Category_name
FROM product join category on product.CategoryId=category.CategoryId";

// Hakuehto
if(isset($_POST['param'])) $sql = $sql." WHERE CONCAT(Name,ProductId,Gender,Description) LIKE '%".$_POST['param']."%'";

$stmt = $db->prepare($sql); 
$stmt->execute();

$array = array();
while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
    array_push($array, $row);

// Muutetaan taulukoitu data jsoniin
echo json_encode($array);
?>