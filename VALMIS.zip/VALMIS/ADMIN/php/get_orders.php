<?php
require_once ("db-init.php");
$sql;
$stmt;
$sql = "SELECT OrderId,Username,orders.Date 
FROM orders 
join customer on customer.CustomerId=orders.CustomerId";

/* KOSKA OSALLA TESTIKÄYTTÄJISTÄ EI OLE OSOITETTA, KÄYTETÄÄN YLLÄOLEVAA LAUSEKETTA. MUUTOIN:
$sql = "SELECT OrderId,Username,Address_street,orders.Date 
FROM orders 
join customer on customer.CustomerId=orders.CustomerId 
join address on address.CustomerId=customer.CustomerId";*/

// Hakuehto
if(isset($_POST['param'])) $sql = $sql." WHERE CONCAT_WS(Username,Email,First_name,Last_name)
 LIKE '%".$_POST['param']."%'";

$stmt = $db->prepare($sql); 
$stmt->execute();

$array = array();
while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
    array_push($array, $row);

// Muutetaan taulukoitu data jsoniin
echo json_encode($array);
?>