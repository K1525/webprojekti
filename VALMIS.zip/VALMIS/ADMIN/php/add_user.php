<?php
require_once ("db-init.php");
require_once("password_compat-master/lib/password.php");

// Lisätään käyttäjä ja osoite
add_user_to_db($db);

function add_user_to_db($db){
    // Taulukkomuuttujat
    $u = $_POST['user'];
    $a = $_POST['address'];
    $username = (isset($u['0']) && !empty($u['0'])) ? $u['0'] : null;
    $password = (isset($u['1']) && !empty($u['1'])) ? $u['1'] : null;
    $firstname = (isset($u['2']) && !empty($u['2'])) ? $u['2'] : null;
    $lastname = (isset($u['3']) && !empty($u['3'])) ? $u['3'] : null;
    $userLevel = (isset($u['6']) && !empty($u['6'])) ? $u['6'] : null;
    $email = (isset($u['4']) && !empty($u['4'])) ? $u['4'] : null;
    $phone = (isset($u['5']) && !empty($u['5'])) ? $u['5'] : null;
    $street = (isset($u['0']) && !empty($u['0'])) ? $u['0'] : null;
    $zip = (isset($a['1']) && !empty($a['1'])) ? $a['1'] : null;
    $city = (isset($a['2']) && !empty($a['2'])) ? $a['2'] : null;
    $country = (isset($a['3']) && !empty($a['3'])) ? $a['3'] : null;

    // Suolaus
    function generateRandomString($length = 60) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }    
    $random = generateRandomString();
    $finalPassword = $random.$password;
    $hash = password_hash($finalPassword, PASSWORD_BCRYPT);

    // Käyttäjän lisäys
    $stmt = $db->prepare("INSERT INTO customer (Username, Password, First_name, Last_name, Email, Phone, User_level, Password_salt) 
    VALUES (:username, :password, :firstname, :lastname, :email, :phone, :userlevel, :salt)");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $hash);
    $stmt->bindParam(':firstname', $firstname);
    $stmt->bindParam(':lastname', $lastname);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':phone', $phone);
    $stmt->bindParam(':userlevel', $userLevel);
    $stmt->bindParam(':salt', $random);
    $stmt->execute();
    $id = $db->lastInsertId();

    // Käyttäjän osoitteen lisäys
    $stmt2 = $db->prepare("INSERT INTO address (CustomerId, Address_street, Address_zip, Address_city, Address_country) 
    VALUES (:id, :street, :zip, :city, :country)");
    $stmt2->bindParam(':id', $id);
    $stmt2->bindParam(':street', $street);
    $stmt2->bindParam(':zip', $zip);
    $stmt2->bindParam(':city', $city);
    $stmt2->bindParam(':country', $country);
    $stmt2->execute();
    
    echo "Käyttäjä lisätty";
}

?>