<?php
if(!isset($_SESSION)) session_start();
// Hard-koodattu käyttäjä että pääsee testaamaan
if(isset($_POST['user']) && isset($_POST['password'])){
    if($_POST['user']!=="admin" || $_POST['password']!=="sala"){
        printLogin();
        exit();
    }
    else $_SESSION['loggedIn'] = 1;
    return;
}

// Testataan sisäänkirjautuminen
if(!isset($_SESSION['loggedIn'])) {
    printLogin();
    exit();
    $sql;
    $stmt;
    $sql = "SELECT CustomerId,Username,First_name,Last_name,Email,Phone,User_level
    FROM customer WHERE CustomerId=".$_SESSION['customerId'];
    $stmt = $db->prepare($sql); 
    $stmt->execute();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
        // Testataan, että käyttäjä on admin
        if($row['User_level'] == 1){
            echo "Access restricted for administrators only.";
            exit();
        }
        else return;
}

// Kuvittelin, että joku muu tekee kirjautumisruudun, mutta tämä kelpaa testailuun
function printLogin(){
    echo "<div id='login'>
    <h1>Kirjaudu Sisään</h1>
    <form method='post' action='index.php'>
    <input type='text' name='user' placeholder='admin'>admin</input><br>
    <input type='password' name='password' placeholder='sala'>sala</input><br>
    <input type='submit' value='Kirjaudu'></form>
    </div>";
}
   
?>