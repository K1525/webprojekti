
<?php
if(!isset($_SESSION)) session_start();
  
// Kirjaudutaan ulos
if (isset($_SESSION['loggedIn'])) {
    unset($_SESSION['loggedIn']);
}

// Siirretään toiselle sivulle
header("Location: http://" . $_SERVER['HTTP_HOST']
                           . dirname($_SERVER['PHP_SELF']) . '/'
                           . "../index.php");
?>