//GLOBAALI DATA MUUTTUJA
var tuoteData;
var sliderVal = [0,1000]; 
var currentG = null;
var currentCat = 8;  

//lajittelun, suodatuksen ja kommentoinnin vuorovaikutus:

$(document).ready(function(){
    
    var range = document.getElementById('range');
    
    //suodatus
    
    $(".clickable").click(function(event){
        var catid = $(this).attr("name");
        var param = $(this).parent().attr("name");
        $.ajax({
            type: "GET",
            url: "filter.php?id="+catid+"&param="+param+"&price_min="+sliderVal[0]+"&price_max="+sliderVal[1],             
            dataType: "html",   //expect html to be returned                
            success: function(response){                    
                $("#tuotetaulu").html(response); 
               // alert(response);
            }
         });
    });
    
    // kommentointi
    
    $(document).on("click","#commentbutton",function(event){
        console.log("kkkk");
       insert_comment(); 
    });
    
    //lajittelu
    $(".sort_item").click(function(event){
        get_sorted_products($(this).attr("data-sort"),$(this).attr("data-order"));
    });
    
   var range = document.getElementById('range');
                range.style.height = '15px';
                range.style.margin = '0 auto 30px';
                
                noUiSlider.create(range, {
                    start: [ 0, 300 ], // luvut, joista aloitetaan lukuasteikolla
                    margin: 5,          // painikkeiden minimiväli
                    limit: 300,         // painikkeiden maksimiväli
                    connect: true,      // Display a colored bar between the handles, must be true if behavior = drag
                    orientation: 'horizontal',  // miten päin asteikko esitetään
                    behaviour: 'tap-drag',      // Move handle on tap, bar is draggable
                    step: 5,                    //asteikon tarkkuus
                    tooltips: true,
                    range: {
                        'min': 0,
                        'max': 300
                    }                          //asteikon väli
                    
                });
    
    
    //Suodatus
    range.noUiSlider.on('change', function ( values, handle ) {
        sliderVal = range.noUiSlider.get();
        var catid = currentCat;
        var param = currentG;
console.log(sliderVal[0]);
        $.ajax({
            type: "GET",
            url: "filter.php?id="+catid+"&param="+param+"&price_min="+sliderVal[0]+"&price_max="+sliderVal[1],                      
            success: function(response){                   
                $("#tuotetaulu").html(response); 

            }
         });
    });
});

function insert_comment(){
    var comment = $("#comment").val();
    $.ajax({
        url: "post-comment.php",
        method: "POST",
        data: { data: comment }
    }).done(function(data) {
        console.log(data);
        $("#commentlist").append(data);
        console.log("Kommentti lisätty");
    });
}

function get_sorted_products(sort,order) {



    $.ajax({ 
            type: "POST",
            url: "sort.php",
            data: {sort: sort, order: order}
            
         }).done(function(products) {
            console.log(products);
            $("#tuotetaulu").html(products);
    });
    
    
} 


