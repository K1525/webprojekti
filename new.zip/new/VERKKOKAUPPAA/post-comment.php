<?php
require_once("db-init.php");
if(!isset($_SESSION)) session_start();

if(isset($_POST["data"]))
{
    insert_comment($db); // data muuttuja voi olla esim. array ja sen sisällä tarvittavat tiedot
}

else show_comment($db);

function insert_comment ($db) { 
             
   $comment = (isset($_POST["data"]) && !empty($_POST["data"])) ?  $_POST["data"] : NULL;
   
   // $_SESSION['productId'] = 1;
    $_SESSION['customerId'] = 1;
    
    $productId = $_SESSION['productId'];
    $customerId = $_SESSION['customerId'];
    
    $timestamp = date("Y-m-d h:i:sa ");
    //echo "$productId \n";
    
   $sql = "INSERT INTO product_ratings (Title,Comment,Date,ProductId,CustomerId) VALUES (:f1, :f2, :f5, :f3, :f4)";
   $stmt = $db->prepare($sql);
   $stmt->execute(array(':f1' => $customerId, ':f2' => $comment, ':f3' => $productId ,':f4' => $customerId, ':f5' => $timestamp ));
   
    //SELECT Username FROM customer WHERE CustomerId = '.$customerId.'  

    echo "<div class='alert alert-success' role='alert'>Kommentti lähetetty onnistuneesti.</div>";    
    
    //echo $customerId. " " .$comment. " " .$timestamp;
}

//show_comment($db);

function show_comment ($db) {
   $sql = "SELECT * FROM product_ratings WHERE ProductId={$_SESSION['productId']}"; // 1 tilalle pitää hakea jostain tuotteen ProductId sessiomuuttujista
   $result = $db->query($sql);
    $collapseId = 0;
    //Näytä kommentit nappula
    echo "<div class='center'>";
    echo "<button class='btn btn-default' type='button' data-toggle='collapse' data-target='#collapseExample' aria-expanded='false' aria-controls='collapseExample'>
        Näytä kommentit
    </button>";
    echo "</div>";
    //Collapse
    echo "<div class='collapse' id='collapseExample''>";
   while($row = $result->fetch(PDO::FETCH_ASSOC)) {       
       $output = "       
       <div class='panel-group' id='accordion' role='tablist' aria-multiselectable='true'>
          <div class='panel panel-default'>
            <div class='panel-heading' role='tab' id='headingOne'>
              <h4 class='panel-title'>
                <a role='button' data-toggle='collapse' data-parent='#accordion' href='#{$collapseId}' aria-expanded='true' aria-controls='collapseOne'>            
                  <p class='title'>Päivä: {$row['Date']}</p>
                </a>
              </h4>
            </div>
            <div id='{$collapseId}' class='panel-collapse collapse in' role='tabpanel' aria-labelledby='headingOne'>
              <div class='panel-body'>
                {$row['Comment']}
              </div>
            </div>
    </div>";
   echo $output;
    $collapseId = $collapseId + 1;
   }
    echo "</div>";
}?>