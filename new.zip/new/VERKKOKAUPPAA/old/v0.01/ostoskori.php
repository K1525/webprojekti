<!--
<form method="post" action="ostoskori.php">
    <input type="text" name="productName">
    <input type="text" name="amount">
    <input type="text" name="price">
    <input type="submit" name="submit">
</form>
-->

<?php
session_start();

require_once ("db-init.php");
$haku = "SELECT * FROM product WHERE name like ";
$stmt2 = $db->query("$haku");
$item = $stmt2->fetch(PDO::FETCH_ASSOC);

//Tehdään ostoskori jos ei ole vielä olemassa
if(!isset($_SESSION['cart'])){
    $_SESSION['cart'] = array();
}
if(!isset($_SESSION['id'])){
    $_SESSION['id'] = 0;
}
/*ORIGINAL
if(isset($_REQUEST['submit'])){
    $newdata = array($_REQUEST['productName'], $_REQUEST['amount'], $_REQUEST['price'],
                     "<a href='subtractItem.php?id={$_SESSION['id']}'>-</a>  <a href='addItem.php?id={$_SESSION['id']}'>+</a>  <a href='delete.php?id={$_SESSION['id']}'>Poista</a>");
    array_push($_SESSION['cart'], $newdata);
    $_SESSION['id']++;
    header("Location:ostoskori.php");    
}
*/
if(isset($_REQUEST['submit'])){
    $newdata = array($item['name'], 1, $item['price'],
                     "<a href='subtractItem.php?id={$_SESSION['id']}'>-</a>  <a href='addItem.php?id={$_SESSION['id']}'>+</a>  <a href='delete.php?id={$_SESSION['id']}'>Poista</a>");
    array_push($_SESSION['cart'], $newdata);
    $_SESSION['id']++;
    header("Location:testi.php");    
}

//!!!Poistettaessa rivi matriisista rivien id muuttuu joten linkit eivät ohjaa enään oikein!!!


/*Kokonaishinta*/
$_SESSION['totalPrice'] = 0;

/*Lasketaan kokonaishinta*/
echo "<form method='POST' action='ostoskori.php'>";
for($i = 0; $i < sizeof($_SESSION['cart']); $i++){
    $_SESSION['totalPrice'] = $_SESSION['totalPrice'] + $_SESSION['cart'][$i][2] * $_SESSION['cart'][$i][1];
    echo "{$_SESSION['cart'][$i][0]}|{$_SESSION['cart'][$i][1]}|{$_SESSION['cart'][$i][2]}|{$_SESSION['cart'][$i][3]} <br>";    
}
echo "</form>";

echo "KOKONAISHINTA: {$_SESSION['totalPrice']} <br>";
?>