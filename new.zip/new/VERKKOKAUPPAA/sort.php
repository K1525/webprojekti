<?php 
require_once("db-init.php");

//lajitteluperuste:



        $sql = "select ProductId, Name, Price, Description, gender, File_name
                from product join product_image
                on product_ProductId = ProductId
                order by {$_POST["sort"]} {$_POST["order"]} ";

        $stmt = $db->query("$sql");


//haetaan tietokannasta tuotteet
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            echo    "<div class='col-md-4 product'
                                        id='{$row['ProductId']}'>
                                    <div class='kuvaa'><img src='images/{$row['File_name']}.png' class='tuotekuva'/></div>
                                    <div class='nimi'>{$row['Name']} </div>
                                    <div class='hinta'>{$row['Price']} </div>
                                    <div class='kuvaus'>{$row['Description']} </div>
                                    </div>";  
                        }


?>