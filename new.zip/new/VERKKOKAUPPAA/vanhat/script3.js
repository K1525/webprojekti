var tuotteet;
 
$(document).ready(function(){
    $.ajax({
        url: "tiedot.json",
        cache: false
    }).done(function(data){
        console.log("Tuotteet tulostettiin onnistuneesti");
        console.log(data);
        tuotteet = data; // tässä ladattu data on siirrettävä globaaliksi, jotta näkyy tuonne toiseen "click"-tapahtumaan
        //showTuotteet(data);
    }).fail(function(){
        console.log("Tuotteita ei haettu!");
    }).always(function(){
        console.log("Complete");
    });
});
 
 
 /* MIESTEN TUOTTEET */
    $(document).on('click', '#mlippis', function(showTuote){
        $(".right").empty();
        $.each(tuotteet.tiedot, function(index, t){
            if (t.tyyppi == "lippis"){
                var tuote = $("<div>").addClass("tuote");
                // Create img
                var kuva = $("<img>").attr("class", "thumb").attr("src", t.kuva);
                // Get price
               var hintalappu = $("<div>").attr("class", "price");
                var hinta = $("<p>").attr("class", "hintaNumero").text(t.hinta);
                // get name, description
                var pohja = $("<div>").attr("class", "gradient");
                var nimi = $("<p>").attr("class", "nimi").text(t.nimi);
                var kuvaus = $("<p>").attr("class", "kuvaus").text(t.kuvaus);
 
                pohja.append(nimi, kuvaus);
                hintalappu.append(hinta);
                // append nodes to div
                tuote.append(kuva, hintalappu, pohja);
                // append
                $(".right").append(tuote);
            }
 
        });
    });

     $(document).on('click', '#mpaita', function(showTuote){
        $(".right").empty();
        $.each(tuotteet.tiedot, function(index, t){
            if (t.tyyppi == "mpaita"){
                var tuote = $("<div>").addClass("tuote");
                // Create img
                var kuva = $("<img>").attr("class", "thumb").attr("src", t.kuva);
                // Get price
               var hintalappu = $("<div>").attr("class", "price");
                var hinta = $("<p>").attr("class", "hintaNumero").text(t.hinta);
                // get name, description
                var pohja = $("<div>").attr("class", "gradient");
                var nimi = $("<p>").attr("class", "nimi").text(t.nimi);
                var kuvaus = $("<p>").attr("class", "kuvaus").text(t.kuvaus);
 
                pohja.append(nimi, kuvaus);
                hintalappu.append(hinta);
                // append nodes to div
                tuote.append(kuva, hintalappu, pohja);
                // append
                $(".right").append(tuote);
            }
 
        });
    });

    $(document).on('click', '#mkenka', function(showTuote){
        $(".right").empty();
        $.each(tuotteet.tiedot, function(index, t){
            if (t.tyyppi == "mkenka"){
                var tuote = $("<div>").addClass("tuote");
                // Create img
                var kuva = $("<img>").attr("class", "thumb").attr("src", t.kuva);
                // Get price
               var hintalappu = $("<div>").attr("class", "price");
                var hinta = $("<p>").attr("class", "hintaNumero").text(t.hinta);
                // get name, description
                var pohja = $("<div>").attr("class", "gradient");
                var nimi = $("<p>").attr("class", "nimi").text(t.nimi);
                var kuvaus = $("<p>").attr("class", "kuvaus").text(t.kuvaus);
 
                pohja.append(nimi, kuvaus);
                hintalappu.append(hinta);
                // append nodes to div
                tuote.append(kuva, hintalappu, pohja);
                // append
                $(".right").append(tuote);
            }
 
        });
    });

 /* NAISTEN TUOTTEET */
    $(document).on('click', 'nlippis', function(showTuote){
        $(".right").empty();
        $.each(tuotteet.tiedot, function(index, t){
            if (t.tyyppi == "lippis"){
                var tuote = $("<div>").addClass("tuote");
                // Create img
                var kuva = $("<img>").attr("class", "thumb").attr("src", t.kuva);
                // Get price
               var hintalappu = $("<div>").attr("class", "price");
                var hinta = $("<p>").attr("class", "hintaNumero").text(t.hinta);
                // get name, description
                var pohja = $("<div>").attr("class", "gradient");
                var nimi = $("<p>").attr("class", "nimi").text(t.nimi);
                var kuvaus = $("<p>").attr("class", "kuvaus").text(t.kuvaus);
 
                pohja.append(nimi, kuvaus);
                hintalappu.append(hinta);
                // append nodes to div
                tuote.append(kuva, hintalappu, pohja);
                // append
                $(".right").append(tuote);
            }
 
        });
    });

    $(document).on('click', '#npaita', function(showTuote){
        $(".right").empty();
        $.each(tuotteet.tiedot, function(index, t){
            if (t.tyyppi == "npaita"){
                var tuote = $("<div>").addClass("tuote");
                // Create img
                var kuva = $("<img>").attr("class", "thumb").attr("src", t.kuva);
                // Get price
               var hintalappu = $("<div>").attr("class", "price");
                var hinta = $("<p>").attr("class", "hintaNumero").text(t.hinta);
                // get name, description
                var pohja = $("<div>").attr("class", "gradient");
                var nimi = $("<p>").attr("class", "nimi").text(t.nimi);
                var kuvaus = $("<p>").attr("class", "kuvaus").text(t.kuvaus);
 
                pohja.append(nimi, kuvaus);
                hintalappu.append(hinta);
                // append nodes to div
                tuote.append(kuva, hintalappu, pohja);
                // append
                $(".right").append(tuote);
            }
 
        });
    });
    
    $(document).on('click', '#nkenka', function(showTuote){
        $(".right").empty();
        $.each(tuotteet.tiedot, function(index, t){
            if (t.tyyppi == "nkenka"){
                var tuote = $("<div>").addClass("tuote");
                // Create img
                var kuva = $("<img>").attr("class", "thumb").attr("src", t.kuva);
                // Get price
               var hintalappu = $("<div>").attr("class", "price");
                var hinta = $("<p>").attr("class", "hintaNumero").text(t.hinta);
                // get name, description
                var pohja = $("<div>").attr("class", "gradient");
                var nimi = $("<p>").attr("class", "nimi").text(t.nimi);
                var kuvaus = $("<p>").attr("class", "kuvaus").text(t.kuvaus);
 
                pohja.append(nimi, kuvaus);
                hintalappu.append(hinta);
                // append nodes to div
                tuote.append(kuva, hintalappu, pohja);
                // append
                $(".right").append(tuote);
            }
 
        });
    });

