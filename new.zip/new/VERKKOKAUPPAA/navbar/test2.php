<?php
if(!isset($_SESSION)){ 
        session_start(); 
    } 
include("login.php");


if($_SESSION['loggedIn'] == 1){
    include("navbar_in2.php");
}
else{
    include("navbar_out2.php");
}

//echo "<p>{$_SESSION['loggedIn']}</p>";


?>